from django.urls import path
from .views import *

app_name = "fasilitas_hotel"

urlpatterns = [
    path('show-fasilitas/', show_fasilitas, name = 'show_fasilitas'),
    path('add-fasilitas/', add_fasilitas_hotel, name='add_fasilitas_hotel'),
    # path('update/', get_update_fasilitas, name = 'get-update-fasilitas'),
    # path('delete/', delete_fasilitas, name = 'delete-fasilitas'),
]