from django.apps import AppConfig


class FasilitasHotelConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fasilitas_hotel'
