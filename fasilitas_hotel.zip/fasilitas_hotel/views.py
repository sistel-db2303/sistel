from django.shortcuts import render
from .forms import AddFasilitasForm
from django.http import HttpResponseRedirect
from .queries import submit_fasilitas, get_fasilitas
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse
from django.core import serializers
from django.shortcuts import redirect
from django.urls import reverse
from django.utils.http import urlencode

# Create your views here.

@csrf_exempt
def add_fasilitas_hotel(request):
    if request.method == 'POST':
        nama_hotel = request.POST['nama_hotel']
        hotel_branch = request.POST['hotel_branch']
        nama_fasilitas = request.POST['nama_fasilitas']
        submit_fasilitas(nama_hotel, hotel_branch, nama_fasilitas)
        url = reverse('fasilitas_hotel:show_fasilitas')+ '?'+urlencode({'nama_hotel':nama_hotel, 'hotel_branch':hotel_branch})
        print(url)
        return redirect(url)

def show_fasilitas(request):
    nama_hotel = request.GET['nama_hotel']
    hotel_branch = request.GET['hotel_branch']
    facilities = get_fasilitas(nama_hotel, hotel_branch)
    context = {
        'facilities': facilities
    }
    
    return HttpResponse(facilities)


#  if request.method == "POST":
#         form = AddFasilitasForm(request.POST)
#         if form.is_valid():
#             nama_fasilitas_hotel = form.cleaned_data['nama_fasilitas']
#             submit_fasilitas(nama_fasilitas_hotel)
#     else:
#         context = {
#             "form" : AddFasilitasForm()
#     }
#         return render(request, 'fasilitas_hotel.html', context)

# def get_add_fasilitas(request):
    
#     return render(request, 'add_fasilitas.html')

# def get_update_fasilitas(request):
#     return render(request, 'update_fasilitas.html')


# def delete_fasilitas(request, pk):
#     if(request.method == "DELETE"):
#         addfasilitas = AddFasilitas.objects.get(pk = id)
#         addfasilitas.delete()

#     return render(request, 'fasilitas_hotel.html')
